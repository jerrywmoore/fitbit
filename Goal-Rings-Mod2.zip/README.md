# Goal Rings

A simple watch face with rings to show progress toward activity goals. Currently only for Fitbit Versa.

![Screenshot on Fitbit Versa](versa-screenshot.png)

# Future Updates

These are just some ideas I've come up with that I might add to the watch face at some point

 * Rings that change color when you hit each goal
 * Goal streak tracking (would be tough)